Device configuration for the Samsung Galaxy J7 Prime

Copyright (C) 2017 The LineageOS Project

Copyright (C) 2017 Siddhant Naik

Copyright (C) 2022 Otus9051
