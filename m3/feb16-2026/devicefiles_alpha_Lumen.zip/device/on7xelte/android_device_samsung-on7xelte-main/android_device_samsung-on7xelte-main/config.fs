[cpefs/]
mode: 0771
user: AID_SYSTEM
group: AID_RADIO
caps: 0

[efs/]
mode: 0771
user: AID_SYSTEM
group: AID_RADIO
caps: 0
