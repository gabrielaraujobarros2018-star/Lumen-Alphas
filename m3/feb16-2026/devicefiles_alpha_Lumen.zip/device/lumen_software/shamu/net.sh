#!/usr/bin/env bash
#
# net.sh — Simple network interface helper (modern Linux, iproute2 style)
# Compatible with kernels 3.x → 6.x+
#
# Usage examples:
#   sudo ./net.sh show
#   sudo ./net.sh list
#   sudo ./net.sh up enp3s0
#   sudo ./net.sh down wlan0
#   sudo ./net.sh set enp3s0 192.168.55.77/24
#   sudo ./net.sh set enp3s0 192.168.55.77/24 192.168.55.1
#   sudo ./net.sh dhcp enp3s0
#   sudo ./net.sh flush enp3s0
#

set -u
set -e

die() {
    echo "Error: $*" >&2
    exit 1
}

require_root() {
    [[ $EUID -eq 0 ]] || die "This action requires root privileges (try sudo)"
}

show_help() {
    cat << 'EOF'
Usage: sudo ./net.sh <command> [arguments]

Commands:
  list / show          List all interfaces and brief status
  status <ifname>      Detailed status of one interface
  up <ifname>          Bring interface up
  down <ifname>        Bring interface down
  set <ifname> <ip/cidr> [gateway]    Set static IPv4 + optional default gateway
  dhcp <ifname>        Request DHCP address (via dhclient)
  flush <ifname>       Remove all IPv4 addresses from interface
  help                 Show this help

Examples:
  sudo ./net.sh set enp4s0 192.168.1.222/24 192.168.1.1
  sudo ./net.sh dhcp wlan0
  sudo ./net.sh flush eth0
EOF
    exit 0
}

list_interfaces() {
    printf "%-12s %-8s %-18s %-15s %s\n" "Interface" "State" "MAC" "IPv4" "Description"
    echo "--------------------------------------------------------------------------------"
    ip -br link show | while read -r line; do
        read -r dev state rest <<< "$line"
        mac=$(ip link show "$dev" | awk '/link/ && /ether/ {print $2}')
        ip4=$(ip -4 -br addr show "$dev" | awk '{print $3}' || echo "-")
        desc=$(ip link show "$dev" | grep -o '^[0-9]\+:.*state' | sed 's/.*: //; s/:.*//')
        printf "%-12s %-8s %-18s %-15s %s\n" "$dev" "\( state" " \){mac:--}" "\( {ip4:--}" " \){desc:--}"
    done
}

case "${1:-}" in
    list|show)
        list_interfaces
        ;;

    status)
        [[ -z ${2:-} ]] && die "Usage: $0 status <interface>"
        ip addr show "$2" || die "No such interface: $2"
        ;;

    up)
        require_root
        [[ -z ${2:-} ]] && die "Usage: $0 up <interface>"
        ip link set "$2" up || die "Failed to bring $2 up"
        echo "Interface $2 is up"
        ;;

    down)
        require_root
        [[ -z ${2:-} ]] && die "Usage: $0 down <interface>"
        ip link set "$2" down || die "Failed to bring $2 down"
        echo "Interface $2 is down"
        ;;

    set)
        require_root
        [[ $# -lt 3 ]] && die "Usage: $0 set <interface> <ip/cidr> [gateway]"
        iface="$2"
        addr="$3"
        gw="${4:-}"

        ip addr flush dev "$iface" 2>/dev/null || true
        ip addr add "$addr" dev "$iface" || die "Failed to add address $addr"
        ip link set "$iface" up || die "Failed to set $iface up"

        if [[ -n $gw ]]; then
            ip route replace default via "$gw" dev "$iface" || die "Failed to set gateway $gw"
            echo "Default route via $gw added"
        fi

        echo "Configured $iface with $addr"
        ;;

    dhcp)
        require_root
        [[ -z ${2:-} ]] && die "Usage: $0 dhcp <interface>"
        iface="$2"

        if command -v dhclient >/dev/null; then
            dhclient -v "$iface" || die "dhclient failed on $iface"
        elif command -v dhcpcd >/dev/null; then
            dhcpcd "$iface" || die "dhcpcd failed on $iface"
        else
            die "No DHCP client found (dhclient or dhcpcd required)"
        fi
        ;;

    flush)
        require_root
        [[ -z ${2:-} ]] && die "Usage: $0 flush <interface>"
        ip addr flush dev "$2" && echo "All IPv4 addresses removed from $2"
        ;;

    ""|help|-h|--help)
        show_help
        ;;

    *)
        echo "Unknown command: $1"
        show_help
        ;;
esac